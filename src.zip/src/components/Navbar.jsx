import { Link, NavLink, useLocation } from "react-router-dom";
import { ArrowRight, Coffee, Croissant, GlassWater, MapPin, Sandwich, ShoppingCart, Star, UtensilsCrossed } from "lucide-react";
import { useCart } from "../context/useCart";
import { getCartCount } from "../utils/cartHelpers";
import { CATEGORIES } from "../data/menuItems";

// One icon per category, so the second row is built from the same CATEGORIES list as the menu page
const CATEGORY_ICONS = {
  "Hot Drinks": Coffee,
  "Cold Drinks": GlassWater,
  "Sweets & Bakery": Croissant,
  Savoury: Sandwich,
  Deals: Star,
};

// A static navbar: it is always visible at the top of the page and scrolls away with it.
function Navbar() {
  const { lines } = useCart();
  const count = getCartCount(lines);
  const location = useLocation();
  // Which category is open right now (from the address ?category=...), so its button is highlighted
  const activeCategory = location.pathname === "/" ? new URLSearchParams(location.search).get("category") : null;

  return (
    <header className="topbar">
      <div className="container topbar-inner">
        <Link to="/" className="topbar-brand">
          <Coffee aria-hidden="true" />
          <span>
            Cafe <b>Corner</b>
          </span>
        </Link>

        <nav aria-label="Main" className="topbar-nav">
          <ul className="topbar-links">
            <li>
              <NavLink to="/" end>
                <UtensilsCrossed aria-hidden="true" />
                <span>Menu</span>
              </NavLink>
            </li>
            <li>
              <NavLink to="/contact">
                <MapPin aria-hidden="true" />
                <span>Contact</span>
              </NavLink>
            </li>
          </ul>
        </nav>

        <div className="topbar-actions">
          <NavLink
            to="/cart"
            className="cart-link"
            aria-label={`Cart, ${count} ${count === 1 ? "item" : "items"}`}
          >
            <ShoppingCart aria-hidden="true" />
            <span>Cart</span>
            {/* The key changes with the count, so the badge replays its pop animation */}
            {count > 0 && (
              <span className="badge" key={count} aria-hidden="true">
                {count}
              </span>
            )}
          </NavLink>
          <Link to="/" className="order-btn">
            Order now
            <ArrowRight aria-hidden="true" />
          </Link>
        </div>
      </div>

      {/* Second row: always visible category links (on phones it scrolls sideways) */}
      <nav aria-label="Menu categories" className="subbar">
        <ul className="container subbar-list">
          <li>
            <Link to="/" className={location.pathname === "/" && !activeCategory ? "subbar-link subbar-active" : "subbar-link"}>
              All items
            </Link>
          </li>
          {CATEGORIES.map((name) => {
            const Icon = CATEGORY_ICONS[name];
            return (
              <li key={name}>
                <Link
                  to={`/?category=${encodeURIComponent(name)}`}
                  className={activeCategory === name ? "subbar-link subbar-active" : "subbar-link"}
                >
                  <Icon aria-hidden="true" />
                  {name}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </header>
  );
}

export default Navbar;
